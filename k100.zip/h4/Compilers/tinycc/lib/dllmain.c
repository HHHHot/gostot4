//+---------------------------------------------------------------------------

#include <windows.h>

BOOL WINAPI DllMain (HINSTANCE hDll, DWORD dwReason, LPVOID lpReserved)
{
	return TRUE;
}

